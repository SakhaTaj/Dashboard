/* ============================================================
   MISDTC ADMIN CONSOLE — INSTALL GUIDE (PHP + MySQL backend)
   Copy the text between the backticks. This is documentation only.
   ============================================================ */
`
WHAT YOU HAVE
-------------
Front-end (built in Moda, exported as HTML):
  index.html   -> the admin console
  login.html   -> the sign-in page (export of the /login route)
  images/, fonts/  -> assets included in the Moda export

Backend (these backend/*.php.js files — rename to *.php on your server):
  config.php        DB connection + session + helpers (EDIT THIS)
  auth.php          login / logout / session
  all.php           bulk boot load (small tables + counts)
  students.php      paginated list + CRUD   (scales to 10,000s)
  fees.php          paginated list + CRUD   (scales to 10,000s)
  courses.php       full list + CRUD
  batches.php       full list + CRUD
  placements.php    list + CRUD
  certificates.php  list + CRUD
  institute.php     get / update institute details
  schema.sql        MySQL tables + indexes + seed admin

RECOMMENDED FOLDER LAYOUT ON YOUR SERVER (e.g. malnadskills.com)
----------------------------------------------------------------
  /admin/index.html
  /admin/login.html
  /admin/images/...
  /admin/fonts/...
  /admin/api/config.php
  /admin/api/auth.php
  /admin/api/all.php
  /admin/api/students.php   (and the rest of the .php files)

With this layout the default API base '/admin/api' works everywhere.

STEP-BY-STEP
------------
1. In cPanel -> MySQL Databases: create a database + a user, and add the
   user to the database with ALL privileges. Note the DB name/user/pass.

2. In phpMyAdmin -> your DB -> Import (or SQL tab): paste the SQL from
   schema.sql.js (between its SQL START / SQL END markers) and run it.
   This creates all tables + indexes and a default admin login:
        username: admin    password: admin123

3. Rename each backend/*.php.js to *.php (strip the .js and the comment
   wrapper — keep only the PHP that is inside the backticks). Upload them
   to /admin/api/.

4. Edit /admin/api/config.php: set DB_HOST, DB_NAME, DB_USER, DB_PASS.
   If your site is HTTPS, uncomment the 'secure' => true cookie line.

5. Export the Moda site (Export -> Export as HTML). Upload index.html,
   login.html, images/, fonts/ into /admin/.

6. In BOTH index.html and login.html, confirm the API base:
      login.html:  const API_BASE = './backend';
      index.html:  const API = { enabled:true, base:'/admin/api' };
   (In index.html you MUST flip enabled to true — see next section.)

7. Visit https://yourdomain.com/admin/login.html and sign in with
   admin / admin123. Change the password from Settings afterward.

TURNING ON DATABASE MODE IN index.html
---------------------------------------
The console ships in demo mode so it also works inside Moda preview.
On your server, open index.html and set:
      const API = { enabled:true, base:'/admin/api' };
When enabled:true the app loads/saves through your PHP + MySQL and
redirects to login.html if the session is missing.

WHY THIS SCALES TO 10,000s OF RECORDS
-------------------------------------
- MySQL, not the browser, stores the data (no 5MB localStorage cap).
- students.php and fees.php return only ONE PAGE (~50 rows) at a time,
  filtered/sorted in SQL using indexes (see schema.sql). The browser
  never holds all rows in memory or in the DOM.
- Search is sent to the server (?q=...) so MySQL does the work.

SECURITY NOTES
--------------
- Always run over HTTPS in production and enable the secure cookie.
- Change the default admin password immediately.
- All queries use prepared statements (no SQL injection).
- Never commit real DB credentials to a public repo.
`
