<?php
require __DIR__ . '/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

if($action === 'login'){
    $b = body();
    $username = trim($b['username'] ?? '');
    $password = $b['password'] ?? '';
    $stmt = db()->prepare("SELECT * FROM admin_users WHERE username=? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if($user && password_verify($password, $user['password_hash'])){
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $user['id'];
        $_SESSION['admin_name'] = $user['full_name'];
        $_SESSION['admin_role'] = $user['role'] ?? 'admin';
        $_SESSION['logged_in'] = true;
        // Return role to frontend
        echo json_encode(['ok'=>true, 'name'=>$user['full_name'], 'role'=>$user['role'] ?? 'admin']);
    } else {
        http_response_code(401);
        echo json_encode(['error'=>'Invalid username or password']);
    }
    exit;
}

if($action === 'logout'){
    session_destroy();
    echo json_encode(['ok'=>true]);
    exit;
}

if($action === 'me'){
    if(!empty($_SESSION['admin_id'])){
        echo json_encode([
            'ok'   => true,
            'name' => $_SESSION['admin_name'],
            'role' => $_SESSION['admin_role'] ?? 'admin'
        ]);
    }else{
        http_response_code(401);
        echo json_encode(['error'=>'auth']);
    }
    exit;
}

http_response_code(404);
echo json_encode(['error'=>'Unknown action']);