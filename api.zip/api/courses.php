<?php
require __DIR__ . '/config.php';
require_auth();

$cols = ['name','dept','duration','fee','seats'];
$method = $_SERVER['REQUEST_METHOD'];

if (in_array($method, ['POST','PUT','DELETE'])) {
    require_admin();
}

// Restore
if ($method === 'GET' && isset($_GET['restore'])) {
    $id = $_GET['restore'];
    db()->prepare('UPDATE courses SET deleted = 0 WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}
// Permanent delete
if ($method === 'GET' && isset($_GET['permanent_delete'])) {
    $id = $_GET['permanent_delete'];
    db()->prepare('DELETE FROM courses WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

if ($method === 'GET') {
    $where = 'deleted = 0';
    if (!empty($_GET['trash'])) {
        $where = 'deleted = 1';
    }
    echo json_encode(db()->query("SELECT * FROM courses WHERE $where ORDER BY name")->fetchAll());
    exit;
}

if ($method === 'POST') {
    $b = only(body(), $cols);
    $id = gen_id('c');
    $b['id'] = $id;
    $b['deleted'] = 0;
    $keys = array_keys($b);
    $ph = implode(',', array_fill(0, count($keys), '?'));
    db()->prepare("INSERT INTO courses (" . implode(',', $keys) . ") VALUES ($ph)")->execute(array_values($b));
    echo json_encode(['id' => $id]);
    exit;
}

if ($method === 'PUT') {
    $id = $_GET['id'] ?? '';
    $b = only(body(), $cols);
    $set = implode(',', array_map(fn($k) => "$k = ?", array_keys($b)));
    $args = array_values($b);
    $args[] = $id;
    db()->prepare("UPDATE courses SET $set WHERE id = ?")->execute($args);
    echo json_encode(['ok' => true]);
    exit;
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    db()->prepare('UPDATE courses SET deleted = 1 WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'method not allowed']);