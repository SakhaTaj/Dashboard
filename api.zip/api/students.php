<?php
require __DIR__ . '/config.php';
require_auth();

$cols = ['reg','name','gender','phone','email','aadhar','qualification','courseId','batchId',
         'dob','guardian','address','admitDate','status'];
$method = $_SERVER['REQUEST_METHOD'];

if (in_array($method, ['POST','PUT','DELETE'])) {
    require_admin();
}

// Restore
if ($method === 'GET' && isset($_GET['restore'])) {
    $id = $_GET['restore'];
    db()->prepare('UPDATE students SET deleted = 0 WHERE id = ?')->execute([$id]);
    db()->prepare('UPDATE fees SET deleted = 0 WHERE studentId = ?')->execute([$id]);
    db()->prepare('UPDATE placements SET deleted = 0 WHERE studentId = ?')->execute([$id]);
    db()->prepare('UPDATE certificates SET deleted = 0 WHERE studentId = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}
// Permanent delete
if ($method === 'GET' && isset($_GET['permanent_delete'])) {
    $id = $_GET['permanent_delete'];
    db()->prepare('DELETE FROM fees WHERE studentId = ?')->execute([$id]);
    db()->prepare('DELETE FROM placements WHERE studentId = ?')->execute([$id]);
    db()->prepare('DELETE FROM certificates WHERE studentId = ?')->execute([$id]);
    db()->prepare('DELETE FROM students WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

// List with trash filter
if ($method === 'GET' && isset($_GET['list'])) {
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per  = min(200, max(1, (int)($_GET['per'] ?? 50)));
    $off  = ($page - 1) * $per;
    $where = ['deleted = 0'];
    $args = [];

    if (!empty($_GET['trash'])) {
        $where[0] = 'deleted = 1';
    }
    if (!empty($_GET['q'])) {
        $where[] = '(name LIKE ? OR reg LIKE ? OR phone LIKE ? OR aadhar LIKE ?)';
        $like = '%' . $_GET['q'] . '%';
        array_push($args, $like, $like, $like, $like);
    }
    if (!empty($_GET['status'])) { $where[] = 'status = ?'; $args[] = $_GET['status']; }
    if (!empty($_GET['courseId'])) { $where[] = 'courseId = ?'; $args[] = $_GET['courseId']; }
    if (!empty($_GET['feeStatus'])) {
        $fs = $_GET['feeStatus'];
        if ($fs === 'paid') {
            $where[] = "id IN (SELECT s2.id FROM students s2 JOIN courses c ON c.id = s2.courseId LEFT JOIN (SELECT studentId, SUM(amount) AS paid FROM fees WHERE deleted=0 GROUP BY studentId) f ON f.studentId = s2.id WHERE COALESCE(f.paid, 0) >= c.fee AND s2.status != 'Dropped')";
        } elseif ($fs === 'pending') {
            $where[] = "id IN (SELECT s2.id FROM students s2 JOIN courses c ON c.id = s2.courseId LEFT JOIN (SELECT studentId, SUM(amount) AS paid FROM fees WHERE deleted=0 GROUP BY studentId) f ON f.studentId = s2.id WHERE COALESCE(f.paid, 0) < c.fee AND s2.status != 'Dropped')";
        }
    }

    $wsql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
    $sortMap = ['name'=>'name', 'reg'=>'reg', 'admitDate'=>'admitDate DESC', 'status'=>'status'];
    $sortKey = $_GET['sort'] ?? 'name';
    $order = isset($sortMap[$sortKey]) ? $sortMap[$sortKey] : 'name';

    $total = db()->prepare("SELECT COUNT(*) FROM students $wsql");
    $total->execute($args);
    $total = (int)$total->fetchColumn();

    $st = db()->prepare("SELECT * FROM students $wsql ORDER BY $order LIMIT $per OFFSET $off");
    $st->execute($args);
    $rows = $st->fetchAll();

    $fee = db()->prepare('SELECT COALESCE(SUM(amount),0) FROM fees WHERE studentId = ? AND deleted=0');
    foreach ($rows as &$r) {
        $fee->execute([$r['id']]);
        $r['paid'] = (int)$fee->fetchColumn();
    }
    echo json_encode(['rows'=>$rows,'total'=>$total,'page'=>$page,'per'=>$per,
                      'pages'=>max(1,(int)ceil($total/$per))]);
    exit;
}

// POST – create
if ($method === 'POST') {
    $b = only(body(), $cols);
    $id = gen_id('s');
    $b['id'] = $id;
    $b['deleted'] = 0;
    $keys = array_keys($b);
    $ph = implode(',', array_fill(0, count($keys), '?'));
    $sql = 'INSERT INTO students (' . implode(',', $keys) . ") VALUES ($ph)";
    db()->prepare($sql)->execute(array_values($b));
    echo json_encode(['id' => $id]);
    exit;
}

// PUT – update
if ($method === 'PUT') {
    $id = $_GET['id'] ?? '';
    $b = only(body(), $cols);
    if (!$id || !$b) { http_response_code(400); echo json_encode(['error'=>'bad request']); exit; }
    $set = implode(',', array_map(fn($k) => "$k = ?", array_keys($b)));
    $args = array_values($b); $args[] = $id;
    db()->prepare("UPDATE students SET $set WHERE id = ?")->execute($args);
    echo json_encode(['ok' => true]);
    exit;
}

// DELETE – soft delete (move to trash)
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    db()->prepare('UPDATE students SET deleted = 1 WHERE id = ?')->execute([$id]);
    db()->prepare('UPDATE fees SET deleted = 1 WHERE studentId = ?')->execute([$id]);
    db()->prepare('UPDATE placements SET deleted = 1 WHERE studentId = ?')->execute([$id]);
    db()->prepare('UPDATE certificates SET deleted = 1 WHERE studentId = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'method not allowed']);