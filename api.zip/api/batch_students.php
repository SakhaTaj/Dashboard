<?php
require __DIR__ . '/config.php';
require_auth();

header('Content-Type: application/json');

$sql = "
  SELECT
    c.id   AS courseId,
    c.name AS courseName,
    b.id   AS batchId,
    b.name AS batchName,
    b.start,
    b.status AS batchStatus,
    s.id   AS studentId,
    s.reg,
    s.name AS studentName,
    s.gender,
    s.phone,
    s.email,
    s.guardian,
    s.address,
    s.admitDate,
    s.dob,
    s.status AS studentStatus
  FROM courses c
  LEFT JOIN batches b ON b.courseId = c.id
  LEFT JOIN students s ON s.batchId = b.id
  ORDER BY c.name, b.start DESC, s.name
";

$stmt = db()->query($sql);
$rows = $stmt->fetchAll();

$courses = [];
foreach ($rows as $row) {
    $cid = $row['courseId'];
    if (!isset($courses[$cid])) {
        $courses[$cid] = [
            'courseId'   => $cid,
            'courseName' => $row['courseName'],
            'batches'    => []
        ];
    }
    if ($row['batchId'] === null) continue;

    $bid = $row['batchId'];
    if (!isset($courses[$cid]['batches'][$bid])) {
        $courses[$cid]['batches'][$bid] = [
            'batchId'     => $bid,
            'batchName'   => $row['batchName'],
            'start'       => $row['start'],
            'batchStatus' => $row['batchStatus'],
            'students'    => []
        ];
    }
    if ($row['studentId'] !== null) {
        // Exclude aadhar and qualification
        $courses[$cid]['batches'][$bid]['students'][] = [
            'studentId'     => $row['studentId'],
            'reg'           => $row['reg'],
            'studentName'   => $row['studentName'],
            'gender'        => $row['gender'],
            'phone'         => $row['phone'],
            'email'         => $row['email'],
            'guardian'      => $row['guardian'],
            'address'       => $row['address'],
            'admitDate'     => $row['admitDate'],
            'dob'           => $row['dob'],
            'studentStatus' => $row['studentStatus']
        ];
    }
}

foreach ($courses as &$course) {
    $course['batches'] = array_values($course['batches']);
}
$out = array_values($courses);

echo json_encode($out);