<?php
echo password_hash('view@MISDTC', PASSWORD_DEFAULT);