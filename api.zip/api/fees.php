<?php
require __DIR__ . '/config.php';
require_auth();

$cols = ['studentId','date','amount','mode','receiptNo','note'];
$method = $_SERVER['REQUEST_METHOD'];

if (in_array($method, ['POST','PUT','DELETE'])) {
    require_admin();
}

// Restore
if ($method === 'GET' && isset($_GET['restore'])) {
    $id = $_GET['restore'];
    db()->prepare('UPDATE fees SET deleted = 0 WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}
// Permanent delete
if ($method === 'GET' && isset($_GET['permanent_delete'])) {
    $id = $_GET['permanent_delete'];
    db()->prepare('DELETE FROM fees WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

// Sum by student
if ($method === 'GET' && isset($_GET['sum']) && isset($_GET['studentId'])) {
    $st = db()->prepare('SELECT COALESCE(SUM(amount), 0) FROM fees WHERE studentId = ? AND deleted=0');
    $st->execute([$_GET['studentId']]);
    $paid = (int)$st->fetchColumn();
    header('Content-Type: application/json');
    echo json_encode(['paid' => $paid]);
    exit;
}

// List
if ($method === 'GET' && isset($_GET['list'])) {
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per  = min(200, max(1, (int)($_GET['per'] ?? 50)));
    $off  = ($page - 1) * $per;
    $where = ['f.deleted = 0'];
    $args = [];

    if (!empty($_GET['trash'])) {
        $where[0] = 'f.deleted = 1';
    }
    if (!empty($_GET['studentId'])) { $where[] = 'f.studentId = ?'; $args[] = $_GET['studentId']; }
    if (!empty($_GET['q'])) {
        $where[] = '(f.receiptNo LIKE ? OR s.name LIKE ?)';
        $like = '%' . $_GET['q'] . '%';
        array_push($args, $like, $like);
    }

    $wsql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
    $total = db()->prepare("SELECT COUNT(*) FROM fees f LEFT JOIN students s ON s.id=f.studentId $wsql");
    $total->execute($args);
    $total = (int)$total->fetchColumn();

    $st = db()->prepare("SELECT f.*, s.name AS studentName, s.reg AS studentReg
                         FROM fees f LEFT JOIN students s ON s.id=f.studentId
                         $wsql ORDER BY f.date DESC LIMIT $per OFFSET $off");
    $st->execute($args);
    $rows = $st->fetchAll();
    echo json_encode(['rows'=>$rows,'total'=>$total,'page'=>$page,'per'=>$per,
                      'pages'=>max(1,(int)ceil($total/$per))]);
    exit;
}

// POST – create
if ($method === 'POST') {
    $b = only(body(), $cols);
    $id = gen_id('f');
    $b['id'] = $id;
    $b['deleted'] = 0;
    $keys = array_keys($b);
    $ph = implode(',', array_fill(0, count($keys), '?'));
    db()->prepare('INSERT INTO fees (' . implode(',', $keys) . ") VALUES ($ph)")->execute(array_values($b));
    echo json_encode(['id' => $id]);
    exit;
}

// PUT – update
if ($method === 'PUT') {
    $id = $_GET['id'] ?? '';
    $b = only(body(), $cols);
    $set = implode(',', array_map(fn($k) => "$k = ?", array_keys($b)));
    $args = array_values($b);
    $args[] = $id;
    db()->prepare("UPDATE fees SET $set WHERE id = ?")->execute($args);
    echo json_encode(['ok' => true]);
    exit;
}

// DELETE – soft delete
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    db()->prepare('UPDATE fees SET deleted = 1 WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'method not allowed']);