<?php
require __DIR__ . '/config.php';
require_auth();

header('Content-Type: application/json');

$out = [];
$out['institute']    = db()->query('SELECT * FROM institute WHERE id=1')->fetch() ?: null;
$out['courses']      = db()->query('SELECT * FROM courses WHERE deleted=0 ORDER BY name')->fetchAll();
$out['batches']      = db()->query('SELECT * FROM batches WHERE deleted=0 ORDER BY start DESC')->fetchAll();
$out['placements']   = db()->query('SELECT * FROM placements WHERE deleted=0 ORDER BY date DESC LIMIT 500')->fetchAll();
$out['certificates'] = db()->query('SELECT * FROM certificates WHERE deleted=0 ORDER BY issueDate DESC LIMIT 500')->fetchAll();

$out['counts'] = [
  'students'  => (int) db()->query("SELECT COUNT(*) FROM students WHERE deleted=0")->fetchColumn(),
  'active'    => (int) db()->query("SELECT COUNT(*) FROM students WHERE deleted=0 AND status='Active'")->fetchColumn(),
  'completed' => (int) db()->query("SELECT COUNT(*) FROM students WHERE deleted=0 AND status='Completed'")->fetchColumn(),
  'collected' => (int) db()->query("SELECT COALESCE(SUM(amount),0) FROM fees WHERE deleted=0")->fetchColumn(),
  'pending'   => (int) db()->query(
    "SELECT COALESCE(SUM(c.fee - COALESCE(f.paid, 0)), 0)
     FROM students s
     JOIN courses c ON c.id = s.courseId
     LEFT JOIN (
         SELECT studentId, SUM(amount) AS paid
         FROM fees
         WHERE deleted=0
         GROUP BY studentId
     ) f ON f.studentId = s.id
     WHERE s.deleted=0 AND s.status != 'Dropped'"
  )->fetchColumn(),
  'placed'    => (int) db()->query('SELECT COUNT(*) FROM placements WHERE deleted=0')->fetchColumn(),
];

// chart data
$stmt = db()->query("
  SELECT DATE_FORMAT(date, '%b') AS month, COALESCE(SUM(amount),0) AS total
  FROM fees
  WHERE deleted=0 AND date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
  GROUP BY month
  ORDER BY MIN(date)
");
$out['chart_fees'] = $stmt->fetchAll();

$stmt = db()->query("
  SELECT c.dept, COUNT(s.id) AS count
  FROM students s
  JOIN courses c ON c.id = s.courseId
  WHERE s.deleted=0 AND s.status != 'Dropped'
  GROUP BY c.dept
  ORDER BY count DESC
");
$out['chart_depts'] = $stmt->fetchAll();

// trash counts
$out['trash_counts'] = [
  'students'    => (int) db()->query("SELECT COUNT(*) FROM students WHERE deleted=1")->fetchColumn(),
  'fees'        => (int) db()->query("SELECT COUNT(*) FROM fees WHERE deleted=1")->fetchColumn(),
  'placements'  => (int) db()->query("SELECT COUNT(*) FROM placements WHERE deleted=1")->fetchColumn(),
  'certificates'=> (int) db()->query("SELECT COUNT(*) FROM certificates WHERE deleted=1")->fetchColumn(),
  'courses'     => (int) db()->query("SELECT COUNT(*) FROM courses WHERE deleted=1")->fetchColumn(),
  'batches'     => (int) db()->query("SELECT COUNT(*) FROM batches WHERE deleted=1")->fetchColumn(),
];

echo json_encode($out);