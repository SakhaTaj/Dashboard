CREATE TABLE IF NOT EXISTS admin_users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(60)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name     VARCHAR(120) DEFAULT 'Administrator',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS institute (
  id      INT PRIMARY KEY DEFAULT 1,
  trust   VARCHAR(255),    
  name    VARCHAR(255),    
  short   VARCHAR(60),
  address VARCHAR(255),
  phone   VARCHAR(120),
  email   VARCHAR(120),
  website VARCHAR(120),
  footer  VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS courses (
  id       VARCHAR(40) PRIMARY KEY,
  name     VARCHAR(200) NOT NULL,
  dept     VARCHAR(80),
  duration VARCHAR(60),
  fee      INT DEFAULT 0,
  seats    INT DEFAULT 30
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS batches (
  id       VARCHAR(40) PRIMARY KEY,
  name     VARCHAR(120),
  courseId VARCHAR(40),
  start    DATE,
  end      DATE,
  status   VARCHAR(30),
  trainer  VARCHAR(120),
  INDEX idx_batches_course (courseId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS students (
  id            VARCHAR(40) PRIMARY KEY,
  reg           VARCHAR(40),
  name          VARCHAR(160) NOT NULL,
  gender        VARCHAR(20),
  phone         VARCHAR(30),
  email         VARCHAR(120),
  aadhar        VARCHAR(20)   DEFAULT NULL,
  qualification VARCHAR(255)  DEFAULT NULL,
  courseId      VARCHAR(40),
  batchId       VARCHAR(40),
  dob           DATE NULL,
  guardian      VARCHAR(160),
  address       VARCHAR(255),
  admitDate     DATE NULL,
  status        VARCHAR(30) DEFAULT 'Active',
  INDEX idx_students_name (name),
  INDEX idx_students_reg (reg),
  INDEX idx_students_phone (phone),
  INDEX idx_students_aadhar (aadhar),
  INDEX idx_students_course (courseId),
  INDEX idx_students_status (status),
  INDEX idx_students_admit (admitDate)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fees (
  id        VARCHAR(40) PRIMARY KEY,
  studentId VARCHAR(40),
  date      DATE NULL,
  amount    INT DEFAULT 0,
  mode      VARCHAR(40),
  receiptNo VARCHAR(60),
  note      VARCHAR(255),
  INDEX idx_fees_student (studentId),
  INDEX idx_fees_date (date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS placements (
  id        VARCHAR(40) PRIMARY KEY,
  studentId VARCHAR(40),
  company   VARCHAR(160),
  role      VARCHAR(120),
  package   VARCHAR(60),
  date      DATE NULL,
  INDEX idx_place_student (studentId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS certificates (
  id        VARCHAR(40) PRIMARY KEY,
  studentId VARCHAR(40),
  certNo    VARCHAR(80),
  issueDate DATE NULL,
  grade     VARCHAR(10),
  INDEX idx_cert_student (studentId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO institute (id, trust, name, short, address, phone, email, website, footer) VALUES
 (1,
  'Malnad Education & Charitable Trust(R), Shivamogga',
  'Malnad Institute of Skill Development & Training Center',
  'MISDTC',
  'Dastageer Industrial Park, Opposite Max Hospital, N T Road, Shivamogga, Karnataka, India',
  '+91 9008920238, +91 9986437327, +91 9739911566',
  'malnadskill@gmail.com',
  'malnadskills.com',
  'ISO 9001:2015 Certified �� Affiliated to ESSCI (NSDC) �� Skill India'
 )
 ON DUPLICATE KEY UPDATE
   trust=VALUES(trust),
   name=VALUES(name),
   short=VALUES(short),
   address=VALUES(address),
   phone=VALUES(phone),
   email=VALUES(email),
   website=VALUES(website),
   footer=VALUES(footer);

INSERT INTO admin_users (username, password_hash, full_name) VALUES
 ('admin', '$2y$10$9vzjR5tZ4IhbTkjI2KnP2OWRGVVt35SuY7nGiubc.2J2v0KUuzDi.', 'Administrator')
 ON DUPLICATE KEY UPDATE username=username;
 
 
ALTER TABLE admin_users ADD COLUMN role VARCHAR(20) DEFAULT 'admin';

INSERT INTO admin_users (username, password_hash, full_name, role) VALUES
('viewer', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Viewer', 'viewer')
ON DUPLICATE KEY UPDATE username=username;


-- for admin
UPDATE admin_users 
SET password_hash = '$2y$10$YOUR_NEW_HASH_HERE' 
WHERE username = 'admin';


-- Insert viewer user (password: viewer123)
INSERT IGNORE INTO admin_users (username, password_hash, full_name, role) VALUES
('viewer', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Viewer', 'viewer');

-- Make sure admin has role 'admin'
UPDATE admin_users SET role = 'admin' WHERE username = 'admin';



UPDATE admin_users 
SET password_hash = '$2y$10$YVr.ai5CKCNNX5UTCh8QAu5gxlIssCMSKqNiRfxBAm0aCuB.CHGHu' 
WHERE username = 'viewer';
