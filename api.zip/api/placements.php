<?php
require __DIR__ . '/config.php';
require_auth();

$cols = ['studentId','company','role','package','date'];
$method = $_SERVER['REQUEST_METHOD'];

if (in_array($method, ['POST','PUT','DELETE'])) {
    require_admin();
}

// Restore
if ($method === 'GET' && isset($_GET['restore'])) {
    $id = $_GET['restore'];
    db()->prepare('UPDATE placements SET deleted = 0 WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}
// Permanent delete
if ($method === 'GET' && isset($_GET['permanent_delete'])) {
    $id = $_GET['permanent_delete'];
    db()->prepare('DELETE FROM placements WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

// GET list – exclude deleted by default, with trash param
if ($method === 'GET') {
    $where = 'p.deleted = 0';
    if (!empty($_GET['trash'])) {
        $where = 'p.deleted = 1';
    }
    $stmt = db()->query(
        "SELECT p.*, s.name AS studentName, s.reg AS studentReg
         FROM placements p
         LEFT JOIN students s ON s.id=p.studentId
         WHERE $where
         ORDER BY p.date DESC LIMIT 1000"
    );
    echo json_encode($stmt->fetchAll());
    exit;
}

// POST – create
if ($method === 'POST') {
    $b = only(body(), $cols);
    $id = gen_id('p');
    $b['id'] = $id;
    $b['deleted'] = 0;
    $keys = array_keys($b);
    $ph = implode(',', array_fill(0, count($keys), '?'));
    db()->prepare("INSERT INTO placements (" . implode(',', $keys) . ") VALUES ($ph)")->execute(array_values($b));
    echo json_encode(['id' => $id]);
    exit;
}

// PUT – update
if ($method === 'PUT') {
    $id = $_GET['id'] ?? '';
    $b = only(body(), $cols);
    $set = implode(',', array_map(fn($k) => "$k = ?", array_keys($b)));
    $args = array_values($b);
    $args[] = $id;
    db()->prepare("UPDATE placements SET $set WHERE id = ?")->execute($args);
    echo json_encode(['ok' => true]);
    exit;
}

// DELETE – soft delete
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    db()->prepare('UPDATE placements SET deleted = 1 WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'method not allowed']);