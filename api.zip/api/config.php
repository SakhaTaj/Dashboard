<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'malnae77_malnad_admin');
define('DB_USER', 'malnae77_malnad_user');
define('DB_PASS', 'Adminmalnad@121');

// Only set cookie params and start session if not already active
if (session_status() === PHP_SESSION_NONE) {
    $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => $isSecure
    ]);
    session_start();
}

function db() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch(PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database connection failed']);
            exit;
        }
    }
    return $pdo;
}

function body() {
    $raw = file_get_contents("php://input");
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function require_auth() {
    if (empty($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
}

function require_admin() {
    if (empty($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Write access denied']);
        exit;
    }
}

function only($data, $keys) {
    return array_intersect_key($data, array_flip($keys));
}

function gen_id($prefix) {
    return $prefix . bin2hex(random_bytes(8));
}