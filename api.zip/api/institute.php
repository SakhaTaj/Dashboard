<?php
require __DIR__ . '/config.php';
require_auth();

$cols = ['name','short','address','phone','email','footer'];
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'PUT') {
    require_admin();
}

if ($method === 'GET') {
  echo json_encode(db()->query('SELECT * FROM institute WHERE id=1')->fetch() ?: null);
  exit;
}
if ($method === 'PUT') {
  $b = only(body(), $cols);
  if (!$b) { echo json_encode(['ok'=>true]); exit; }
  $set = implode(',', array_map(fn($k)=>"$k = ?", array_keys($b)));
  $args = array_values($b);
  db()->exec('INSERT IGNORE INTO institute (id) VALUES (1)');
  db()->prepare("UPDATE institute SET $set WHERE id = 1")->execute($args);
  echo json_encode(['ok'=>true]); exit;
}
http_response_code(405); echo json_encode(['error'=>'method not allowed']);