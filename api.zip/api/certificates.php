<?php
require __DIR__ . '/config.php';
require_auth();

$cols = ['studentId','certNo','issueDate','grade'];
$method = $_SERVER['REQUEST_METHOD'];

if (in_array($method, ['POST','PUT','DELETE'])) {
    require_admin();
}

// Restore
if ($method === 'GET' && isset($_GET['restore'])) {
    $id = $_GET['restore'];
    db()->prepare('UPDATE certificates SET deleted = 0 WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}
// Permanent delete
if ($method === 'GET' && isset($_GET['permanent_delete'])) {
    $id = $_GET['permanent_delete'];
    db()->prepare('DELETE FROM certificates WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

if ($method === 'GET') {
    $where = 'c.deleted = 0';
    if (!empty($_GET['trash'])) {
        $where = 'c.deleted = 1';
    }
    $stmt = db()->query(
        "SELECT c.*, s.name AS studentName, s.courseId
         FROM certificates c
         LEFT JOIN students s ON s.id=c.studentId
         WHERE $where
         ORDER BY c.issueDate DESC LIMIT 1000"
    );
    echo json_encode($stmt->fetchAll());
    exit;
}

if ($method === 'POST') {
    $b = only(body(), $cols);
    $id = gen_id('ct');
    $b['id'] = $id;
    $b['deleted'] = 0;
    $keys = array_keys($b);
    $ph = implode(',', array_fill(0, count($keys), '?'));
    db()->prepare("INSERT INTO certificates (" . implode(',', $keys) . ") VALUES ($ph)")->execute(array_values($b));
    echo json_encode(['id' => $id]);
    exit;
}

if ($method === 'PUT') {
    $id = $_GET['id'] ?? '';
    $b = only(body(), $cols);
    $set = implode(',', array_map(fn($k) => "$k = ?", array_keys($b)));
    $args = array_values($b);
    $args[] = $id;
    db()->prepare("UPDATE certificates SET $set WHERE id = ?")->execute($args);
    echo json_encode(['ok' => true]);
    exit;
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    db()->prepare('UPDATE certificates SET deleted = 1 WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'method not allowed']);