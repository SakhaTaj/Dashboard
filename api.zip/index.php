<?php
session_start();

// If already logged in, go to dashboard
if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Optional: include config if needed
if (file_exists(__DIR__ . '/api/config.php')) {
    require __DIR__ . '/api/config.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/png" href="/images/logo.png">
  <title>Sign in · MISDTC Admin Console</title>

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Poppins:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    :root {
      --navy: #0f2c4d;
      --navy-800: #123a63;
      --blue: #1d6fb8;
      --accent: #f7941d;
      --accent-600: #e07f0a;
      --red: #dc3545;
      --ink: #1b2733;
      --muted: #6b7c8f;
      --line: #e6ebf1;
      --bg: #f4f7fb;
    }
    body {
      margin: 0;
      font-family: "Open Sans", system-ui, sans-serif;
      background: var(--bg);
      color: var(--ink);
    }
    h1, h2, h3, .font-head {
      font-family: "Poppins", system-ui, sans-serif;
    }
    .field {
      width: 100%;
      border: 1px solid var(--line);
      border-radius: 0.6rem;
      padding: 0.7rem 0.85rem;
      font-size: 0.95rem;
      outline: none;
      background: #fff;
      font-family: inherit;
    }
    .field:focus {
      border-color: var(--blue);
      box-shadow: 0 0 0 3px rgba(29, 111, 184, 0.12);
    }
    label.lbl {
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--muted);
      margin-bottom: 0.35rem;
      display: block;
    }
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.4rem;
      font-weight: 600;
      font-size: 0.95rem;
      padding: 0.75rem 1rem;
      border-radius: 0.6rem;
      cursor: pointer;
      border: none;
      transition: 0.15s;
      width: 100%;
    }
    .btn-primary {
      background: var(--blue);
      color: #fff;
    }
    .btn-primary:hover {
      background: var(--navy);
    }
  </style>
   <script>
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        return false;
    });

    document.addEventListener('keydown', function(e) {

        if (e.ctrlKey && e.key === 'u') {
            e.preventDefault();
            return false;
        }

        if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i')) {
            e.preventDefault();
            return false;
        }

        if (e.ctrlKey && e.shiftKey && (e.key === 'J' || e.key === 'j')) {
            e.preventDefault();
            return false;
        }

        if (e.key === 'F12') {
            e.preventDefault();
            return false;
        }

        if (e.ctrlKey && e.shiftKey && (e.key === 'C' || e.key === 'c')) {
            e.preventDefault();
            return false;
        }
    });
</script>
</head>
<body>

<div class="min-h-screen grid lg:grid-cols-2">

  <!-- Brand panel -->
  <div class="hidden lg:flex flex-col justify-between p-12 text-white relative overflow-hidden" style="background: linear-gradient(150deg, var(--navy), var(--blue));">
    <div class="flex items-center gap-3 relative z-10">
      <div class="w-12 h-12 rounded-xl bg-white flex items-center justify-center overflow-hidden">
        <img src="images/misdtc-logo.jpg" alt="MISDTC" class="w-10 h-10 object-contain">
      </div>
      <div>
        <p class="font-head font-bold text-lg leading-tight">MISDTC</p>
        <p class="text-white/60 text-sm leading-tight">Admin Console</p>
      </div>
    </div>
    
    <div class="relative z-10">
      <h1 class="font-head font-bold text-4xl leading-tight">Malnad Institute of Skill Development &amp; Training Centre</h1>
      <p class="text-white/70 mt-4 max-w-md">Manage students, admissions, fees, placements and certificates — built to run for years and hold tens of thousands of records.</p>
    </div>

    <p class="text-white/50 text-xs relative z-10">ISO 9001:2015 Certified · Affiliated to ESSCI (NSDC) · Skill India</p>

    <!-- Decorative shapes -->
    <div class="absolute -right-16 -top-16 w-72 h-72 rounded-full bg-white/10"></div>
    <div class="absolute -right-24 bottom-10 w-56 h-56 rounded-full bg-white/5"></div>
  </div>

  <!-- Form panel -->
  <div class="flex items-center justify-center p-6 sm:p-10">
    <div class="w-full max-w-sm">
      <div class="flex lg:hidden items-center gap-3 mb-8">
        <div class="w-11 h-11 rounded-xl bg-white border border-[var(--line)] flex items-center justify-center overflow-hidden">
          <img src="images/misdtc-logo.jpg" alt="MISDTC" class="w-9 h-9 object-contain">
        </div>
        <div>
          <p class="font-head font-bold leading-tight text-[var(--navy)]">MISDTC</p>
          <p class="text-[var(--muted)] text-xs leading-tight">Admin Console</p>
        </div>
      </div>

      <h2 class="font-head font-bold text-2xl text-[var(--navy)]">Sign in</h2>
      <p class="text-sm text-[var(--muted)] mt-1 mb-6">Enter your administrator credentials to continue.</p>

      <div id="err" class="hidden mb-4 text-sm rounded-lg px-3 py-2" style="background:#fdecee; color:var(--red);"></div>

      <form id="loginForm" class="space-y-4">
        <div>
          <label for="username" class="lbl">Username</label>
          <input id="username" name="username" class="field" autocomplete="username" required autofocus>
        </div>
        <div>
          <label for="password" class="lbl">Password</label>
          <input id="password" name="password" type="password" class="field" autocomplete="current-password" required>
        </div>
        <button class="btn btn-primary" id="submitBtn" type="submit">Sign in</button>
      </form>

    </div>
  </div>
</div>

<script>
const API_BASE = '/admin/api';

const form = document.getElementById('loginForm');
const errBox = document.getElementById('err');
const btn = document.getElementById('submitBtn');

function showErr(msg) { 
  errBox.textContent = msg; 
  errBox.classList.remove('hidden'); 
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errBox.classList.add('hidden');
  btn.disabled = true; 
  btn.textContent = 'Signing in…';

  const data = Object.fromEntries(new FormData(form));

  try {
    const r = await fetch(`${API_BASE}/auth.php?action=login`, {
      method: 'POST', 
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (r.ok) {
      const json = await r.json();
      // Store role in localStorage for viewer mode detection
      localStorage.setItem('userRole', json.role || 'admin');
      localStorage.setItem('userName', json.name || '');
      location.href = 'dashboard.php';
    } else {
      const j = await r.json().catch(() => ({}));
      showErr(j.error || 'Invalid username or password.');
    }
  } catch (err) {
    showErr('Could not reach the server. Check that PHP is running and API_BASE is correct.');
  } finally {
    btn.disabled = false; 
    btn.textContent = 'Sign in';
  }
});
</script>
</body>
</html>